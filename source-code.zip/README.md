# Nived Mehta — Video Editing Portfolio

A responsive portfolio for video editing, motion design, filmmaking, and content leadership. Built with React, Vite, TypeScript, Motion, and Three.js, with a warm ivory and muted olive visual style.

## Features

- Five video projects with supplied thumbnails, editing-tool filters, and direct Instagram links.
- Interactive TechText name, animated cloud background, word-by-word introduction, Canvas Reveal skill cards, pointer-following mask, and loading indicator.
- DAUD case study: 20,000 to 42,200 followers in less than three months, with brand collaborations attributed to work through DAUD Run Club.
- Personal portrait, Instagram and LinkedIn links, and direct WhatsApp contact.
- Responsive layouts, reduced-motion handling, keyboard controls, and touch alternatives for pointer effects.
- Bundled Manrope and DM Sans fonts.

## Local development

```sh
npm install
npm run dev
```

The development server normally runs at `http://127.0.0.1:5173/`. Vite reports the actual address if the port is occupied.

```sh
npm run build
npm run preview
```

The build runs TypeScript checks and generates `dist/`. The preview command serves the production build locally; its address appears in the terminal.

## GitHub Pages

`.github/workflows/deploy.yml` builds and deploys the site to GitHub Pages on pushes to `main`. In the repository's **Settings → Pages**, select **GitHub Actions** as the deployment source.

Vite uses a relative base (`./`), and public assets are resolved relative to that base so the site can run under a GitHub Pages repository path. Keep new asset references compatible with subdirectory hosting. Deployment status and the published address are available in the repository's Actions and Pages settings.

## Content and assets

- `src/App.jsx`: page layout, navigation, results, and social links.
- `src/data/videos.json`: project titles, categories, Instagram URLs, and thumbnail mappings.
- `src/components/WorkGallery.jsx`: gallery filters and recorded reel metrics.
- `src/components/DaudCaseStudy.jsx`: DAUD growth and collaboration details.
- `src/components/WhatsAppButton.jsx`: shared contact link.
- `public/thumbnails/` and `public/images/`: supplied video covers and portrait.
- `src/index.css` and component stylesheets: visual styling.

The gallery contains Core Reveal and A-Quant State Capitalism under After Effects, DAUD × OPPO Reno Land and DAUD × Vendi Silver under Premiere Pro, and DAUD Running Community under Community content. Reel metrics are snapshots recorded on **14 October 2026**; `~` indicates a rounded count.

**200,000 total views** is a separate creator-reported result across the broader body of work. The two short films are mentioned as edited and directed; their titles, watch links, and artwork have not yet been supplied.

## Effects and attribution

- [TechText — React Bits](https://reactbits.dev/text-animations/tech-text)
- [CloudShader — Aceternity UI](https://ui.aceternity.com/registry/cloud-shader.json)
- [SVG Mask Effect — Aceternity UI](https://ui.aceternity.com/components/svg-mask-effect)
- [Canvas Reveal Effect — Aceternity UI](https://ui.aceternity.com/registry/canvas-reveal-effect.json)
- [Text Generate Effect — Aceternity UI](https://ui.aceternity.com/components/text-generate-effect)
- [LoaderOne — Aceternity UI](https://ui.aceternity.com/registry/loader.json)

Components have been adapted to the portfolio's content, local styles, and interaction needs. Personal images and portfolio content are not third-party template assets.

## Optional: React Bits Pro Speeding Text

The total-views figure currently renders as static text. The optional [Speeding Text](https://pro.reactbits.dev/docs/components/speeding-text) component requires a valid React Bits Pro license and is not included. `components.json` is configured to read `REACTBITS_LICENSE_KEY` from the local environment.

Follow the [official installation instructions](https://pro.reactbits.dev/docs/installation), complete the Tailwind/shadcn setup required by the chosen variant, and then install it:

```sh
npx shadcn@latest add @reactbits-starter/speeding-text-tw
```

Keep license values in an ignored local environment file. Never commit them, expose them in client-side code, or prefix them with `VITE_`. The current site builds and runs without this optional component or its license.
