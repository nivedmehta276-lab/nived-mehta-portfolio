import { lazy, Suspense, useState } from 'react';
import { ArrowUpRight, ArrowUp, Menu, X, Instagram, Linkedin } from 'lucide-react';
import PortfolioHero from './components/PortfolioHero';
import FeaturedMacbook from './components/FeaturedMacbook';
import WorkGallery from './components/WorkGallery';
import PortfolioIntro from './components/PortfolioIntro';
import DaudCaseStudy from './components/DaudCaseStudy';
import ContactCTA from './components/ContactCTA';
import PortfolioLoader from './components/PortfolioLoader';
import { WHATSAPP_URL } from './components/WhatsAppButton';
const CreativeToolkit = lazy(() => import('./components/CreativeToolkit'));
const InsideTheEdit = lazy(() => import('./components/InsideTheEdit'));

function Header() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <header className="site-header">
      <a className="wordmark" href="#top" onClick={close} aria-label="Nived Mehta — back to top">nived mehta<span className="wordmark-dot">.</span></a>
      <nav className={`site-nav ${open ? 'is-open' : ''}`} aria-label="Main navigation" id="main-nav">
        <a href="#work" onClick={close}>Work</a><a href="#daud" onClick={close}>Impact</a><a href="#about" onClick={close}>About</a>
        <a href="#contact" className="nav-contact" onClick={close}>Let’s talk <ArrowUpRight size={15}/></a>
      </nav>
      <button className="menu-toggle" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls="main-nav" aria-label={open ? 'Close menu' : 'Open menu'}>{open ? <X size={22}/> : <Menu size={22}/>}</button>
    </header>
  );
}
export default function App() {
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a><div id="top" /><Header />
      <main id="main">
        <PortfolioHero />
        <div className="portfolio-results" aria-label="Portfolio highlights">
          <div><strong>200,000</strong><p>Total views across my work</p></div>
          <div><strong>42.2<span>k</span></strong><p>DAUD followers grown from 20k</p></div>
          <div><strong>02</strong><p>Short films edited &amp; directed</p></div>
          <a href="#work" className="results-note"><span>A few numbers.<br/>A lot of stories.</span><ArrowUpRight size={22}/></a>
        </div>
        <FeaturedMacbook /><WorkGallery /><DaudCaseStudy /><PortfolioIntro />
        <Suspense fallback={<PortfolioLoader />}><CreativeToolkit /></Suspense>
        <Suspense fallback={<PortfolioLoader />}><InsideTheEdit /></Suspense>
        <ContactCTA />
      </main>
      <footer className="site-footer">
        <a href="#top" className="wordmark">nived mehta<span className="wordmark-dot">.</span></a><p>Made to move you.</p>
        <div className="footer-links">
          <a href="https://www.instagram.com/nived_mehta/" target="_blank" rel="noopener noreferrer" aria-label="Nived Mehta on Instagram"><Instagram size={18}/> Instagram</a>
          <a href="https://www.linkedin.com/in/nived-mehta-7073b1374/" target="_blank" rel="noopener noreferrer" aria-label="Nived Mehta on LinkedIn"><Linkedin size={18}/> LinkedIn</a>
          <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">WhatsApp <ArrowUpRight size={16}/></a>
        </div>
        <a href="#top" className="back-top" aria-label="Back to top"><ArrowUp size={18}/></a>
      </footer>
    </>
  );
}
