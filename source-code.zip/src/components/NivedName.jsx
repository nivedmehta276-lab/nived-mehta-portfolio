'use client';

import TechText from './TechText';
import './NivedName.css';

const themes = {
  warm: { color: '#20231e', accentColor: '#55614b' },
  dark: { color: '#f1eee7', accentColor: '#aaa99f' },
  editorial: { color: '#292624', accentColor: '#985b48' }
};

export default function NivedName({ theme = 'warm', fontFamily = 'Manrope, sans-serif' }) {
  const colors = themes[theme] || themes.warm;

  return (
    <div className="nived-name" style={{ color: colors.color, fontFamily }}>
      <h1 className="nived-name-heading">Nived Mehta</h1>
      <div className="nived-name-animation" aria-hidden="true">
        <TechText
          text="Nived Mehta"
          fontWeight={600}
          fontSize={150}
          reveal="letter"
          dashLength={4}
          dashGap={2}
          specks={15}
          fontFamily={fontFamily}
          color={colors.color}
          accentColor={colors.accentColor}
          letterSpacing={-0.05}
          reach={200}
          softness={0.7}
          strokeWidth={1.5}
          speed={1}
          lineStyle="dashed"
          selection
          labels
          draggable
          sweep
        />
      </div>
    </div>
  );
}
