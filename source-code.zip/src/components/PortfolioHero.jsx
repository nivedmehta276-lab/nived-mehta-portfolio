'use client';

import { TextReveal } from "./ui/text-reveal";
import { LandscapeShader } from './ui/landscape-shader';
import NivedName from './NivedName';
import { ArrowDown, ArrowUpRight } from 'lucide-react';
import './PortfolioHero.css';
export default function PortfolioHero() {
  return <section className="portfolio-hero portfolio-hero-landscape" aria-label="Nived Mehta — video editor and filmmaker">
      <div className="portfolio-hero-background" aria-hidden="true">
        <LandscapeShader />
        
      </div>
      <div className="portfolio-hero-foreground">
        <div className="hero-topline"><p className="portfolio-hero-role"><span /><TextReveal text={" Video editor & filmmaker"} /></p><span className="hero-index"><TextReveal text={"PORTFOLIO / SELECTED WORK"} /></span></div>
        <NivedName theme="dark" />
        <div className="hero-bottomline">
          <p className="portfolio-hero-description"><TextReveal text={"Motion with purpose."} /><br /><span><TextReveal text={"Stories with feeling."} /></span></p>
          <div className="hero-actions"><a href="#work" className="hero-work-button"><TextReveal text={"Explore my work "} /><ArrowDown size={16} /></a><a className="hero-connect" href="https://wa.me/918669659620" target="_blank" rel="noopener noreferrer"><TextReveal text={"Let\u2019s create together "} /><ArrowUpRight size={16} /></a></div>
        </div>
        <div className="hero-footnote"><span><TextReveal text={"AFTER EFFECTS \xB7 PREMIERE PRO \xB7 DIRECTION"} /></span><a href="#work"><TextReveal text={"SCROLL TO EXPLORE "} /><ArrowDown size={12} /></a></div>
      </div>
    </section>;
}
