'use client';

import { CloudShader } from './ui/cloud-shader';
import NivedName from './NivedName';
import { ArrowDown, ArrowUpRight } from 'lucide-react';
import './PortfolioHero.css';

export default function PortfolioHero() {
  return (
    <section className="portfolio-hero" aria-label="Nived Mehta — video editor and filmmaker">
      <div className="portfolio-hero-background" aria-hidden="true">
        <CloudShader
          speed={0.35}
          count={4}
          cloudColor="#faf8f2"
          skyTopColor="#c5cbbd"
          skyBottomColor="#f4f1ea"
        />
      </div>
      <div className="portfolio-hero-foreground">
        <div className="hero-topline"><p className="portfolio-hero-role"><span /> Video editor &amp; filmmaker</p><span className="hero-index">PORTFOLIO / SELECTED WORK</span></div>
        <NivedName theme="warm" />
        <div className="hero-bottomline">
          <p className="portfolio-hero-description">Motion with purpose.<br/><span>Stories with feeling.</span></p>
          <div className="hero-actions"><a href="#work" className="hero-work-button">Explore my work <ArrowDown size={16}/></a><a className="hero-connect" href="https://wa.me/918669659620" target="_blank" rel="noopener noreferrer">Let’s create together <ArrowUpRight size={16}/></a></div>
        </div>
        <div className="hero-footnote"><span>AFTER EFFECTS · PREMIERE PRO · DIRECTION</span><a href="#work">SCROLL TO EXPLORE <ArrowDown size={12}/></a></div>
      </div>
    </section>
  );
}
