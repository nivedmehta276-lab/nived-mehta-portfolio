import { LoaderOne } from './ui/loader';
import './PortfolioLoader.css';

export default function PortfolioLoader() {
  return (
    <div className="portfolio-loader" role="status" aria-live="polite" aria-atomic="true">
      <LoaderOne />
      <p>Loading Nived’s portfolio…</p>
    </div>
  );
}
