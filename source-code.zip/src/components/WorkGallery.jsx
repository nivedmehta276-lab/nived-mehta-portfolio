import videos from '../data/videos.json';
import { useState } from 'react';
import { ArrowUpRight, Play, Eye, Heart } from 'lucide-react';
import './WorkGallery.css';

export default function WorkGallery() {
  const [filter, setFilter] = useState('All work');
  const categories = ['All work', 'After Effects', 'Premiere Pro', 'Community content'];
  const visible = filter === 'All work' ? videos : videos.filter(video => video.category === filter);
  const metrics = { 'core-reveal': ['21,145', '491'], 'a-quant-state-capitalism': ['4,200', '105'], 'daud-oppo-reno-land': ['~123k', '572'], 'daud-vendi-silver': ['22,379', '287'], 'daud-running-community': ['~15k', '314'] };
  return (
    <section className="work-gallery" id="work" aria-labelledby="work-gallery-title">
      <div className="work-gallery-heading">
        <div><p className="section-kicker">01 / THE WORK</p><h2 id="work-gallery-title">Good stories.<br/><span>Even better in motion.</span></h2></div>
        <p className="work-gallery-intro">A selection of edits, experiments, and brand stories.<br/>Made to be watched. Built to be felt.</p>
      </div>
      <div className="work-filters" role="group" aria-label="Filter videos by editing tool">
        {categories.map(category => <button type="button" key={category} aria-pressed={filter === category} onClick={() => setFilter(category)}>{category === 'Community content' ? 'Community' : category}<span>{category === 'All work' ? '05' : String(videos.filter(v=>v.category === category).length).padStart(2,'0')}</span></button>)}
      </div>
      <p className="gallery-announcement" role="status">Showing {visible.length} {visible.length === 1 ? 'video' : 'videos'}</p>
      <div className={`work-gallery-grid ${filter === 'All work' ? 'all-work' : ''}`}>
        {visible.map((video) => (
          <article className="work-card" key={video.id}>
            <a className="work-card-link" href={video.url} target="_blank" rel="noopener noreferrer" aria-label={`Watch ${video.title} on Instagram (opens in a new tab)`}>
              <div className="work-card-media">
                <div className={video.frame === 'instagram-crop' ? 'work-card-instagram-crop' : 'work-card-image-frame'}>
                  <img src={`${import.meta.env.BASE_URL}${video.thumbnail.replace(/^\/+/, '')}`} alt={video.alt} width={video.width} height={video.height} loading="lazy" decoding="async" />
                </div>
                <span className="work-card-play" aria-hidden="true"><Play size={16} fill="currentColor"/></span>
              </div>
              <div className="work-card-meta"><span>{video.category}</span><span>{String(videos.indexOf(video) + 1).padStart(2, '0')}</span></div>
              <div className="work-card-title"><h3>{video.title}</h3><ArrowUpRight size={20}/></div>
              <span className="work-card-watch">Watch on Instagram</span>
            </a>
            <p className="work-card-metrics"><span><Eye size={12}/> {metrics[video.id][0]} views</span><span><Heart size={11}/> {metrics[video.id][1]} likes</span></p>
          </article>
        ))}
      </div>
      <p className="work-metrics-note">Reel metrics recorded 14 Oct 2026. “~” indicates a rounded count. Counts may have changed.</p>
    </section>
  );
}
