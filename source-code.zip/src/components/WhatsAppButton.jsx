export const WHATSAPP_URL = 'https://wa.me/918669659620';

export default function WhatsAppButton({ className = '' }) {
  return (
    <a
      className={className}
      href={WHATSAPP_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with Nived Mehta on WhatsApp (opens in a new tab)"
    >
      Let’s talk on WhatsApp <span aria-hidden="true">↗</span>
    </a>
  );
}
