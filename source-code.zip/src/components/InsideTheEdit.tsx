"use client";

import { TextReveal } from "./ui/text-reveal";
import { MaskContainer } from "./ui/svg-mask-effect";
import './InsideTheEdit.css';
export default function InsideTheEdit() {
  return <section className="inside-edit" aria-labelledby="inside-edit-heading">
      <h2 id="inside-edit-heading"><TextReveal text={"04 / INSIDE THE EDIT"} /></h2>
      <p className="inside-edit-hint"><TextReveal text={"The reveal moves on its own. Touch or move your pointer to guide it."} /></p>
      <MaskContainer revealText={<p><TextReveal text={"Good edits make you feel something."} /></p>} size={10} revealSize={360}><TextReveal text={"After Effects. Premiere Pro. Every detail, considered."} />


      </MaskContainer>
    </section>;
}
