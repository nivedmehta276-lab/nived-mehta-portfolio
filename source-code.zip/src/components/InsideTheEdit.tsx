"use client";

import { MaskContainer } from "./ui/svg-mask-effect";
import './InsideTheEdit.css';

export default function InsideTheEdit() {
  return (
    <section className="inside-edit" aria-labelledby="inside-edit-heading">
      <h2 id="inside-edit-heading">04 / INSIDE THE EDIT</h2>
      <p className="inside-edit-hint">Move your pointer to look beneath the surface.</p>
      <MaskContainer
        revealText={<p>Good edits make you feel something.</p>}
        size={10}
        revealSize={360}
      >
        After Effects. Premiere Pro. Every detail, considered.
      </MaskContainer>
    </section>
  );
}
