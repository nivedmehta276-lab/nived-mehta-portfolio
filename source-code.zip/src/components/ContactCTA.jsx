import { TextReveal } from "./ui/text-reveal";
import WhatsAppButton from './WhatsAppButton';
import './ContactCTA.css';
export default function ContactCTA() {
  return <section className="contact-cta" id="contact" aria-labelledby="contact-cta-title">
      <div className="contact-cta-inner">
        <div className="contact-cta-copy">
          <p className="contact-cta-eyebrow"><TextReveal text={"Let\u2019s create together"} /></p>
          <h2 id="contact-cta-title"><TextReveal text={"Your next story."} /><br /><TextReveal text={"Let\u2019s make it move."} /></h2>
          <p className="contact-cta-description"><TextReveal text={"Have a reel, brand film, or creative idea in mind? Tell me what you\u2019re working on, and let\u2019s shape it into a video worth watching."} />


          </p>
          <dl className="contact-cta-proof">
            <div><dt><TextReveal text={"200,000"} /></dt><dd><TextReveal text={"Total views across my work"} /></dd></div>
            <div><dt><TextReveal text={"2 short films"} /></dt><dd><TextReveal text={"Edited & directed"} /></dd></div>
          </dl>
        </div>
        <div className="contact-cta-action">
          <WhatsAppButton className="contact-cta-button" />
          <p><TextReveal text={"Direct chat with Nived Mehta"} /></p>
        </div>
      </div>
    </section>;
}
