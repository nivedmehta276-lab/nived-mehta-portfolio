import WhatsAppButton from './WhatsAppButton';
import './ContactCTA.css';

export default function ContactCTA() {
  return (
    <section className="contact-cta" id="contact" aria-labelledby="contact-cta-title">
      <div className="contact-cta-inner">
        <div className="contact-cta-copy">
          <p className="contact-cta-eyebrow">Let’s create together</p>
          <h2 id="contact-cta-title">Your next story.<br />Let’s make it move.</h2>
          <p className="contact-cta-description">
            Have a reel, brand film, or creative idea in mind? Tell me what
            you’re working on, and let’s shape it into a video worth watching.
          </p>
          <dl className="contact-cta-proof">
            <div><dt>200,000</dt><dd>Total views across my work</dd></div>
            <div><dt>2 short films</dt><dd>Edited &amp; directed</dd></div>
          </dl>
        </div>
        <div className="contact-cta-action">
          <WhatsAppButton className="contact-cta-button" />
          <p>Direct chat with Nived Mehta</p>
        </div>
      </div>
    </section>
  );
}
