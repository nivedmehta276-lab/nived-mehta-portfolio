import { TextReveal } from "./ui/text-reveal";
import { TextGenerateEffect } from './ui/text-generate-effect';
import './PortfolioIntro.css';
const introduction = 'I’m Nived Mehta, a video editor and filmmaker proficient in After Effects and Premiere Pro. I create motion-led edits, brand content, and community stories, and I’ve edited and directed two short films.';
export default function PortfolioIntro() {
  return <section className="portfolio-intro" id="about" aria-labelledby="portfolio-intro-title">
      <div className="intro-portrait"><img src={`${import.meta.env.BASE_URL}images/nived-mehta-portrait.jpeg`} alt="Nived Mehta wearing headphones outdoors in warm sunlight" width="1024" height="1024" loading="lazy" /><span><TextReveal text={"NIVED MEHTA / BEHIND THE EDIT"} /></span></div>
      <div className="intro-copy"><p className="section-kicker"><TextReveal text={"03 / THE PERSON BEHIND THE PIXELS"} /></p><h2 id="portfolio-intro-title"><TextReveal text={"A little instinct."} /><br /><TextReveal text={"A lot of intention."} /></h2>
      <TextGenerateEffect words={introduction} duration={0.45} />
      <p className="intro-detail"><TextReveal text={"From the energy of a community run to the rhythm of a short film, I care about how an edit feels. I\u2019m also exploring AI video creation with Higgsfield and HeyGen."} /></p>
      <div className="intro-signature"><TextReveal text={"Nived Mehta"} /><span><TextReveal text={"Video editor & filmmaker"} /></span></div></div>
    </section>;
}
