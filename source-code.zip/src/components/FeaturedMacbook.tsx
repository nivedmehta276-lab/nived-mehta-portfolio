import { ArrowUpRight } from 'lucide-react';
import { MacbookScroll } from './ui/macbook-scroll';
import './FeaturedMacbook.css';

export default function FeaturedMacbook() {
  return <section className="featured-macbook" aria-labelledby="macbook-title">
    <p className="section-kicker">A CLOSER LOOK / MOTION DESIGN</p>
    <MacbookScroll
      title={<span>From the timeline.<br/><span>To your screen.</span></span>}
      src={`${import.meta.env.BASE_URL}thumbnails/02-a-quant-state-capitalism.png`}
      alt="A-Quant State Capitalism: Nived Mehta's After Effects work with two chairs and a central logo"
      badge={<span className="macbook-nm-badge">nm.</span>}
      showGradient={false}
    />
    <a className="featured-macbook-watch" href="https://www.instagram.com/reel/Dbm0s34BnLX/" target="_blank" rel="noopener noreferrer">Watch the featured edit <ArrowUpRight size={16}/></a>
  </section>;
}
