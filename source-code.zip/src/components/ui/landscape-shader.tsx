import { useEffect, useRef, useState } from 'react';
import landscapeBuffer from '../../shaders/landscape-buffer.glsl?raw';
import landscapeImage from '../../shaders/landscape-image.glsl?raw';
import './landscape-shader.css';

const vertex = `#version 300 es
in vec2 a_position;
void main() { gl_Position = vec4(a_position, 0.0, 1.0); }
`;
const fragment = (source: string) => `#version 300 es
precision highp float;
precision highp int;
uniform vec3 iResolution;
uniform float iTime;
uniform int iFrame;
uniform sampler2D iChannel0;
out vec4 outputColor;
${source}
void main() { mainImage(outputColor, gl_FragCoord.xy); }
`;

// The supplied Buffer A reprojects its previous frame and stores camera metadata
// in three float pixels. Two floating-point targets preserve that feedback.
export function LandscapeShader() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [status, setStatus] = useState('loading');
  const [generation, setGeneration] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const gl = canvas.getContext('webgl2', {
      alpha: false, antialias: false, depth: false, stencil: false,
      powerPreference: 'low-power', preserveDrawingBuffer: false,
    });
    if (!gl || !gl.getExtension('EXT_color_buffer_float')) {
      setStatus('fallback');
      return;
    }

    const shaders: WebGLShader[] = [];
    const programs: WebGLProgram[] = [];
    const textures: WebGLTexture[] = [];
    const framebuffers: WebGLFramebuffer[] = [];
    let buffer: WebGLBuffer | null = null;
    let vao: WebGLVertexArrayObject | null = null;
    let raf = 0;
    let disposed = false;
    let lost = false;
    let visible = true;
    let frameNumber = 0;
    let previousTarget = 0;
    let elapsed = 0;
    let previousTime = 0;
    let lastDraw = -Infinity;
    const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const disposeGL = () => {
      framebuffers.forEach(item => gl.deleteFramebuffer(item));
      textures.forEach(item => gl.deleteTexture(item));
      programs.forEach(item => gl.deleteProgram(item));
      shaders.forEach(item => gl.deleteShader(item));
      gl.deleteBuffer(buffer);
      gl.deleteVertexArray(vao);
    };
    const compile = (type: number, source: string) => {
      const shader = gl.createShader(type);
      if (!shader) throw new Error('Shader allocation failed');
      shaders.push(shader);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        throw new Error(gl.getShaderInfoLog(shader) || 'Shader compilation failed');
      }
      return shader;
    };
    const makeProgram = (source: string) => {
      const program = gl.createProgram();
      if (!program) throw new Error('Program allocation failed');
      programs.push(program);
      gl.attachShader(program, compile(gl.VERTEX_SHADER, vertex));
      gl.attachShader(program, compile(gl.FRAGMENT_SHADER, fragment(source)));
      gl.bindAttribLocation(program, 0, 'a_position');
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        throw new Error(gl.getProgramInfoLog(program) || 'Shader linking failed');
      }
      return {
        program,
        resolution: gl.getUniformLocation(program, 'iResolution'),
        time: gl.getUniformLocation(program, 'iTime'),
        frame: gl.getUniformLocation(program, 'iFrame'),
        channel: gl.getUniformLocation(program, 'iChannel0'),
      };
    };

    try {
      const scene = makeProgram(landscapeBuffer);
      const image = makeProgram(landscapeImage);
      vao = gl.createVertexArray();
      buffer = gl.createBuffer();
      if (!vao || !buffer) throw new Error('Geometry allocation failed');
      gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      const linear = Boolean(gl.getExtension('OES_texture_float_linear'));
      for (let index = 0; index < 2; index++) {
        const texture = gl.createTexture();
        const framebuffer = gl.createFramebuffer();
        if (!texture || !framebuffer) {
          gl.deleteTexture(texture); gl.deleteFramebuffer(framebuffer);
          throw new Error('Feedback allocation failed');
        }
        textures.push(texture);
        framebuffers.push(framebuffer);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, linear ? gl.LINEAR : gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, linear ? gl.LINEAR : gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      }
      const schedule = () => {
        if (!disposed && !lost && visible && !document.hidden && !raf) raf = requestAnimationFrame(draw);
      };
      const draw = (now: number) => {
        raf = 0;
        if (disposed || lost || !visible || document.hidden) return;
        // Bound the cost of the original terrain/tree ray marcher on phones.
        if (now - lastDraw < 1000 / 18) { schedule(); return; }
        lastDraw = now;
        if (previousTime && !motion.matches) elapsed += Math.min((now - previousTime) / 1000, 0.2);
        previousTime = now;
        const next = 1 - previousTarget;
        gl.bindVertexArray(vao);
        gl.viewport(0, 0, canvas.width, canvas.height);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, textures[previousTarget]);
        gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffers[next]);
        gl.useProgram(scene.program);
        gl.uniform3f(scene.resolution, canvas.width, canvas.height, 1);
        gl.uniform1f(scene.time, motion.matches ? 0 : elapsed);
        gl.uniform1i(scene.frame, frameNumber);
        gl.uniform1i(scene.channel, 0);
        gl.drawArrays(gl.TRIANGLES, 0, 3);

        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.bindTexture(gl.TEXTURE_2D, textures[next]);
        gl.useProgram(image.program);
        gl.uniform3f(image.resolution, canvas.width, canvas.height, 1);
        gl.uniform1i(image.channel, 0);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
        previousTarget = next;
        frameNumber++;
        canvas.dataset.frame = String(frameNumber);
        if (frameNumber === 1) setStatus('ready');
        // Settle antialiasing at a fixed time, then freeze for reduced motion.
        if (!motion.matches || frameNumber < 12) schedule();
      };
      const restart = () => {
        cancelAnimationFrame(raf); raf = 0; previousTime = 0;
        schedule();
      };
      const onMotionChange = () => {
        frameNumber = 0; previousTarget = 0; elapsed = 0;
        restart();
      };
      const resize = () => {
        const { width, height } = canvas.getBoundingClientRect();
        if (!width || !height) return;
        const budget = width <= 760 ? 90000 : 180000;
        const factor = Math.min(1, 640 / width, Math.sqrt(budget / (width * height)));
        const w = Math.max(4, Math.round(width * factor));
        const h = Math.max(4, Math.round(height * factor));
        if (w !== canvas.width || h !== canvas.height) {
          canvas.width = w; canvas.height = h;
          frameNumber = 0; previousTarget = 0;
          textures.forEach((texture, index) => {
            gl.bindTexture(gl.TEXTURE_2D, texture);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, w, h, 0, gl.RGBA, gl.FLOAT, null);
            gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffers[index]);
            gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
            if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
              throw new Error('Floating-point render target unavailable');
            }
            gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
          });
          gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        }
        restart();
      };
      const onResize = () => {
        try { resize(); } catch (error) {
          console.warn('Landscape shader:', error);
          lost = true; cancelAnimationFrame(raf); setStatus('fallback');
        }
      };
      const sizeObserver = new ResizeObserver(onResize);
      const visibilityObserver = new IntersectionObserver(([entry]) => {
        visible = entry.isIntersecting; restart();
      });
      const onLost = (event: Event) => { event.preventDefault(); lost = true; cancelAnimationFrame(raf); raf = 0; setStatus('fallback'); };
      const onRestored = () => { setStatus('loading'); setGeneration(value => value + 1); };
      sizeObserver.observe(canvas);
      visibilityObserver.observe(canvas);
      canvas.addEventListener('webglcontextlost', onLost);
      canvas.addEventListener('webglcontextrestored', onRestored);
      document.addEventListener('visibilitychange', restart);
      motion.addEventListener('change', onMotionChange);
      onResize();
      return () => {
        disposed = true; cancelAnimationFrame(raf);
        sizeObserver.disconnect(); visibilityObserver.disconnect();
        canvas.removeEventListener('webglcontextlost', onLost);
        canvas.removeEventListener('webglcontextrestored', onRestored);
        document.removeEventListener('visibilitychange', restart);
        motion.removeEventListener('change', onMotionChange);
        disposeGL();
      };
    } catch (error) {
      disposed = true; cancelAnimationFrame(raf); disposeGL();
      console.warn('Landscape shader:', error);
      setStatus('fallback');
    }
  }, [generation]);

  return <div className="landscape-shader" data-shader-status={status} aria-hidden="true">
    <canvas ref={canvasRef} className="landscape-shader-canvas" />
  </div>;
}
