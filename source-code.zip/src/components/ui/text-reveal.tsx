import { createElement, useEffect, useRef, useState, type CSSProperties } from 'react';
import './text-reveal.css';

// One observer for every label and paragraph; React retains ownership of the DOM.
const listeners = new WeakMap<Element, () => void>();
let observer: IntersectionObserver | undefined;
export function TextReveal({ text }: { text: string | number }) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    if (!('IntersectionObserver' in window)) { setVisible(true); return; }
    observer ??= new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          listeners.get(entry.target)?.();
          observer?.unobserve(entry.target);
        }
      });
    }, { threshold: 0.05 });
    listeners.set(element, () => setVisible(true));
    observer.observe(element);
    return () => { observer?.unobserve(element); listeners.delete(element); };
  }, []);
  let index = 0;
  return createElement('reveal-text', { ref, 'data-visible': String(visible) },
    String(text).split(/(\s+)/).map((part, key) => /\S/.test(part)
      ? createElement('reveal-word', { key, style: { '--word-delay': `${Math.min(index++ * 0.045, 0.9)}s` } as CSSProperties }, part)
      : part));
}
