"use client";

// Adapted from Aceternity UI's Text Generate Effect.
// https://ui.aceternity.com/registry/text-generate-effect.json
import { useEffect } from "react";
import { motion, stagger, useAnimate, useInView, useReducedMotion } from "motion/react";
import "./text-generate-effect.css";

export function TextGenerateEffect({
  words,
  className = "",
  filter = true,
  duration = 0.5,
}: {
  words: string;
  className?: string;
  filter?: boolean;
  duration?: number;
}) {
  const [scope, animate] = useAnimate();
  const inView = useInView(scope, { once: true, amount: 0.2 });
  const reducedMotion = useReducedMotion();
  const wordsArray = words.trim().split(/\s+/).filter(Boolean);

  useEffect(() => {
    if (!scope.current || !words.trim() || reducedMotion || !inView) return;
    const animation = animate(
      "span",
      { opacity: 1, filter: "blur(0px)" },
      { duration: Math.max(0, duration), delay: stagger(0.055) },
    );
    return () => animation.stop();
  }, [animate, scope, inView, reducedMotion, words, duration, filter]);

  return (
    <p className={`text-generate-effect ${className}`}>
      <span className="text-generate-accessible">{words}</span>
      <motion.span ref={scope} aria-hidden="true" className="text-generate-visual">
        {wordsArray.map((word, index) => (
          <motion.span
            key={`${word}-${index}`}
            style={{ opacity: reducedMotion ? 1 : 0, filter: filter && !reducedMotion ? "blur(6px)" : "none" }}
          >
            {word}{" "}
          </motion.span>
        ))}
      </motion.span>
    </p>
  );
}
