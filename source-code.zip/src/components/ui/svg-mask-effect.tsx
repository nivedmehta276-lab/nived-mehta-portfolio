"use client";

// Adapted from Aceternity UI's SVG Mask Effect by Manu Arora.
// https://ui.aceternity.com/components/svg-mask-effect
import { useRef, useState, type ReactNode, type PointerEvent, type CSSProperties } from "react";
import { motion, useInView, useReducedMotion } from "motion/react";
import "./svg-mask-effect.css";

export function MaskContainer({
  children,
  revealText,
  revealSize = 360,
  className = "",
}: {
  children?: ReactNode;
  revealText?: ReactNode;
  size?: number;
  revealSize?: number;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [interacting, setInteracting] = useState(false);
  const reducedMotion = useReducedMotion();
  const inView = useInView(containerRef, { amount: 0.1 });
  const guideReveal = (event: PointerEvent<HTMLDivElement>) => {
    if (reducedMotion) return;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const diameter = Math.min(revealSize, window.innerWidth * 0.82);
    setPosition({ x: event.clientX - rect.left - diameter / 2, y: event.clientY - rect.top - diameter / 2 });
    setInteracting(true);
  };

  return (
    <div
      ref={containerRef}
      className={`portfolio-mask ${className}`}
      data-interacting={interacting}
      data-in-view={inView}
      style={{ "--reveal-size": `${revealSize}px` } as CSSProperties}
      tabIndex={0}
      role="group"
      aria-label="Inside the edit. The reveal moves automatically. Touch or move your pointer to guide it."
      onPointerDown={guideReveal}
      onPointerMove={guideReveal}
      onPointerUp={(event) => { if (event.pointerType !== "mouse") setInteracting(false); }}
      onPointerLeave={() => setInteracting(false)}
      onPointerCancel={() => setInteracting(false)}
    >
      <div className="portfolio-mask-base">{revealText}</div>
      {!reducedMotion && (
        <motion.div
          aria-hidden="true"
          className="portfolio-mask-overlay"
          animate={{
            "--mask-x": `${position.x}px`,
            "--mask-y": `${position.y}px`,
          }}
          transition={{ duration: 0.15, ease: "linear" }}
        >
          <div className="portfolio-mask-copy">{children}</div>
        </motion.div>
      )}
      <div className="portfolio-mask-accessible">{children}</div>
    </div>
  );
}
