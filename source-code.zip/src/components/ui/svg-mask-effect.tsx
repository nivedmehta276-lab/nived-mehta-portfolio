"use client";

// Adapted from Aceternity UI's SVG Mask Effect by Manu Arora.
// https://ui.aceternity.com/components/svg-mask-effect
import { useRef, useState, type ReactNode } from "react";
import { motion, useReducedMotion } from "motion/react";
import "./svg-mask-effect.css";

export function MaskContainer({
  children,
  revealText,
  size = 10,
  revealSize = 360,
  className = "",
}: {
  children?: ReactNode;
  revealText?: ReactNode;
  size?: number;
  revealSize?: number;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);
  const reducedMotion = useReducedMotion();
  const diameter = hovered ? revealSize : size;

  return (
    <div
      ref={containerRef}
      className={`portfolio-mask ${className}`}
      tabIndex={0}
      role="group"
      aria-label="Inside the edit. Focus here or move your pointer to reveal the process."
      onPointerMove={(event) => {
        if (event.pointerType === "touch" || reducedMotion) return;
        const rect = containerRef.current?.getBoundingClientRect();
        if (!rect) return;
        setPosition({ x: event.clientX - rect.left, y: event.clientY - rect.top });
        setHovered(true);
      }}
      onPointerLeave={() => setHovered(false)}
      onPointerCancel={() => setHovered(false)}
    >
      <div className="portfolio-mask-base">{revealText}</div>
      {!reducedMotion && (
        <motion.div
          aria-hidden="true"
          className="portfolio-mask-overlay"
          animate={{
            opacity: hovered ? 1 : 0,
            "--mask-x": `${position.x - diameter / 2}px`,
            "--mask-y": `${position.y - diameter / 2}px`,
            "--mask-size": `${diameter}px`,
          }}
          transition={{ duration: 0.15, ease: "linear" }}
        >
          <div className="portfolio-mask-copy">{children}</div>
        </motion.div>
      )}
      <div className="portfolio-mask-accessible">{children}</div>
    </div>
  );
}
