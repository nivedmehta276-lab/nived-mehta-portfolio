"use client";

// Adapted from Aceternity UI's Macbook Scroll by Manu Arora.
// Original source: https://ui.aceternity.com/registry/macbook-scroll.json
// Retains the scroll-driven lid rotation, scale and translation, with local
// styles and a responsive keyboard instead of Tailwind and extra icon packages.
import { useEffect, useRef, useState, type ReactNode } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import "./macbook-scroll.css";

const keyRows = [
  ["esc", "◌", "☀", "▤", "⌕", "◉", "☾", "◀", "▶", "▶▶", "◂", "▸", "◉"],
  ["~", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "−", "+", "delete"],
  ["tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "[", "]", "\\"],
  ["caps", "A", "S", "D", "F", "G", "H", "J", "K", "L", ";", "'", "return"],
  ["shift", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "/", "shift"],
  ["fn", "ctrl", "option", "⌘", "space", "⌘", "option", "◀", "▲", "▼", "▶"],
];

export function MacbookScroll({ src, showGradient = false, title, badge, alt = "Selected motion design work by Nived Mehta" }: {
  src: string;
  showGradient?: boolean;
  title?: ReactNode;
  badge?: ReactNode;
  alt?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();
  const [compact, setCompact] = useState(false);
  useEffect(() => {
    const query = window.matchMedia("(max-width: 760px)");
    const update = () => setCompact(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const scaleX = useTransform(scrollYProgress, [0.18, 0.64], [1, compact ? 1.04 : 1.3]);
  const scaleY = useTransform(scrollYProgress, [0.18, 0.64], [0.78, compact ? 1.04 : 1.3]);
  const rotate = useTransform(scrollYProgress, [0.15, 0.35, 0.68], [-28, -20, 0]);
  const translate = useTransform(scrollYProgress, [0.18, 0.7], [0, compact ? -35 : -90]);
  const textY = useTransform(scrollYProgress, [0.2, 0.7], [20, -15]);
  const textOpacity = useTransform(scrollYProgress, [0.22, 0.4], [1, 0]);

  return (
    <div ref={ref} className="macbook-scroll" data-reduced-motion={Boolean(reducedMotion)}>
      <div className="macbook-sticky">
        <motion.h2 id="macbook-title" className="macbook-title" style={{ y: reducedMotion ? 0 : textY, opacity: reducedMotion ? 1 : textOpacity }}>
          {title}
        </motion.h2>
        <div className="macbook-device">
          <div className="macbook-lid-back" aria-hidden="true"><span>NM</span></div>
          <motion.div className="macbook-lid" style={reducedMotion ? undefined : {
            scaleX, scaleY, rotateX: rotate, y: translate,
          }}>
            <div className="macbook-camera" aria-hidden="true" />
            <div className="macbook-display">
              <img src={src} alt={alt} width="490" height="335" loading="lazy" />
              <div className="macbook-screen-caption" aria-hidden="true"><span>NIVED MEHTA</span><span>MOTION / AFTER EFFECTS</span></div>
            </div>
            <span className="macbook-screen-label" aria-hidden="true">Made to move you.</span>
          </motion.div>
          <div className="macbook-deck" aria-hidden="true">
            <div className="macbook-hinge" />
            <div className="macbook-speaker macbook-speaker-left" />
            <div className="macbook-keyboard">
              {keyRows.map((keys, row) => <div className="macbook-key-row" key={row}>
                {keys.map((key, index) => <span key={`${row}-${index}`} className={key === "space" ? "macbook-key macbook-space" : "macbook-key"}>{key === "space" ? "" : key}</span>)}
              </div>)}
            </div>
            <div className="macbook-speaker macbook-speaker-right" />
            <div className="macbook-trackpad" />
            <div className="macbook-notch" />
            {badge && <div className="macbook-badge">{badge}</div>}
            {showGradient && <div className="macbook-deck-gradient" />}
          </div>
        </div>
        <div className="macbook-project-caption"><span>Featured edit / A-Quant State Capitalism</span><span>Scroll to unfold ↓</span></div>
      </div>
    </div>
  );
}
