"use client";

// Adapted from Aceternity UI's Macbook Scroll by Manu Arora.
// Original source: https://ui.aceternity.com/registry/macbook-scroll.json
// Only the artwork leaves the stationary hardware; spring smoothing follows scroll.
import { TextReveal } from "./text-reveal";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { motion, useReducedMotion, useScroll, useSpring, useTransform } from "motion/react";
import "./macbook-scroll.css";
const keyRows = [["esc", "◌", "☀", "▤", "⌕", "◉", "☾", "◀", "▶", "▶▶", "◂", "▸", "◉"], ["~", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "−", "+", "delete"], ["tab", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "[", "]", "\\"], ["caps", "A", "S", "D", "F", "G", "H", "J", "K", "L", ";", "'", "return"], ["shift", "Z", "X", "C", "V", "B", "N", "M", ",", ".", "/", "shift"], ["fn", "ctrl", "option", "⌘", "space", "⌘", "option", "◀", "▲", "▼", "▶"]];
export function MacbookScroll({
  src,
  showGradient = false,
  title,
  badge,
  alt = "Selected motion design work by Nived Mehta"
}: {
  src: string;
  showGradient?: boolean;
  title?: ReactNode;
  badge?: ReactNode;
  alt?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();
  const [compact, setCompact] = useState(false);
  useEffect(() => {
    const query = window.matchMedia("(max-width: 760px)");
    const update = () => setCompact(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  const {
    scrollYProgress
  } = useScroll({
    target: ref,
    offset: ["start start", "end end"]
  });
  const progress = useSpring(scrollYProgress, {
    stiffness: 85,
    damping: 26,
    mass: 0.6
  });
  const scale = useTransform(progress, [0.08, 0.85], [1, compact ? 1.04 : 1.38]);
  const rotate = useTransform(progress, [0.08, 0.8], [-25, 0]);
  const translate = useTransform(progress, [0.08, 0.85], [0, compact ? 360 : 500]);
  const textY = useTransform(progress, [0, 0.5], [0, -25]);
  const textOpacity = useTransform(progress, [0.1, 0.45], [1, 0]);
  return <div ref={ref} className="macbook-scroll" data-reduced-motion={Boolean(reducedMotion)}>
      <div className="macbook-sticky">
        <motion.h2 id="macbook-title" className="macbook-title" style={{
        y: reducedMotion ? 0 : textY,
        opacity: reducedMotion ? 1 : textOpacity
      }}>
          {title}
        </motion.h2>
        <div className="macbook-project-caption"><span><TextReveal text={"Featured edit / A-Quant State Capitalism"} /></span><span><TextReveal text={"Scroll to reveal \u2193"} /></span></div>
        <div className="macbook-device">
          <div className="macbook-lid">
            <div className="macbook-camera" aria-hidden="true" />
            <div className="macbook-display">
              <span className="macbook-screen-monogram" aria-hidden="true">nm.</span>
            </div>
            <span className="macbook-screen-label" aria-hidden="true">Made to move you.</span>
          </div>
          <motion.div className="macbook-artwork" style={reducedMotion ? {
          rotateX: -25
        } : {
          scale,
          rotateX: rotate,
          y: translate
        }}>
            <img src={src} alt={alt} width="490" height="335" loading="lazy" />
          </motion.div>
          <div className="macbook-deck" aria-hidden="true">
            <div className="macbook-hinge" />
            <div className="macbook-speaker macbook-speaker-left" />
            <div className="macbook-keyboard">
              {keyRows.map((keys, row) => <div className="macbook-key-row" key={row}>
                {keys.map((key, index) => <span key={`${row}-${index}`} className={key === "space" ? "macbook-key macbook-space" : "macbook-key"}>{key === "space" ? "" : key}</span>)}
              </div>)}
            </div>
            <div className="macbook-speaker macbook-speaker-right" />
            <div className="macbook-trackpad" />
            <div className="macbook-notch" />
            {badge && <div className="macbook-badge">{badge}</div>}
            {showGradient && <div className="macbook-deck-gradient" />}
          </div>
        </div>
      </div>
    </div>;
}
