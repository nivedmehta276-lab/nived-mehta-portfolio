"use client";

// LoaderOne, adapted from Aceternity UI with local styles and reduced-motion support.
// https://ui.aceternity.com/registry/loader.json
import { motion, useReducedMotion } from "motion/react";
import "./loader.css";

export function LoaderOne() {
  const reducedMotion = useReducedMotion();

  return (
    <div className="loader-one" aria-hidden="true">
      {[0, 1, 2].map((index) => (
        <motion.div
          key={index}
          className="loader-one-dot"
          initial={{ y: 0 }}
          animate={{ y: reducedMotion ? 0 : [0, 10, 0] }}
          transition={reducedMotion ? { duration: 0 } : {
            duration: 1,
            repeat: Infinity,
            repeatType: "loop",
            delay: index * 0.2,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}
