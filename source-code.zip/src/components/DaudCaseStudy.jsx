import './DaudCaseStudy.css';

const collaborations = [
  'MuscleBlaze',
  'OPPO Reno Land',
  'Vendi Silver',
  'Phoenix Mall of Asia, Bengaluru',
];

export default function DaudCaseStudy() {
  return (
    <section className="daud-case-study" id="daud" aria-labelledby="daud-case-title">
      <div className="daud-case-inner">
        <p className="daud-case-eyebrow">02 / Content &amp; community</p>

        <div className="daud-case-layout">
          <div className="daud-case-copy">
            <h2 id="daud-case-title">More than a run.<br />A community in motion.</h2>
            <p className="daud-case-description">
              As Content Head at DAUD, I helped grow the brand page from 20,000 to
              42,200 followers in less than three months. Editing was part of a
              bigger picture: creating content for a community that kept growing.
            </p>
            <dl className="daud-case-details">
              <div>
                <dt>My role</dt>
                <dd>Content Head &amp; video editor</dd>
              </div>
              <div>
                <dt>Page management</dt>
                <dd>DAUD Run Club · June–August</dd>
              </div>
            </dl>
            <a
              className="daud-case-link"
              href="https://www.instagram.com/daudrunclub/"
              target="_blank"
              rel="noopener noreferrer"
            >
              Meet the community
              <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M6 18 18 6M6 6h12v12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="daud-case-visually-hidden"> on Instagram (opens in a new tab)</span>
            </a>
          </div>

          <div className="daud-growth-panel" aria-label="DAUD audience growth, from 20,000 to 42,200 followers in less than three months">
            <div className="daud-growth-topline">
              <span>DAUD / The growth story</span>
              <span className="daud-growth-period">Under 3 months</span>
            </div>
            <div className="daud-growth-headline">
              <span className="daud-growth-percentage">+111<span>%</span></span>
              <span className="daud-growth-label">Audience growth</span>
            </div>

            <div className="daud-growth-endpoints">
              <div>
                <span className="daud-growth-endpoint-label">Started at</span>
                <span className="daud-growth-count">20k</span>
              </div>
              <svg className="daud-growth-arrow" viewBox="0 0 32 32" fill="none" aria-hidden="true">
                <path d="M5 16h22M18 7l9 9-9 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <div>
                <span className="daud-growth-endpoint-label">Grew to</span>
                <span className="daud-growth-count">42.2k</span>
              </div>
            </div>
            <div className="daud-growth-track" aria-hidden="true">
              <span />
              <span />
            </div>
            <div className="daud-growth-footnote">
              <span>Followers</span>
              <span>+22,200 people</span>
            </div>
          </div>
        </div>

        <div className="daud-collaborations">
          <p>Collaborations through DAUD Run Club</p>
          <ul aria-label="Brand and venue collaborations">
            {collaborations.map((brand) => <li key={brand}>{brand}</li>)}
          </ul>
        </div>
      </div>
    </section>
  );
}
