"use client";

import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useInView, useReducedMotion } from "motion/react";
const CanvasRevealEffect = lazy(() => import('./ui/canvas-reveal-effect').then(module => ({ default: module.CanvasRevealEffect })));
import "./CreativeToolkit.css";

const skills = [
  { title: "After Effects", mark: "Ae", level: "Proficient", description: "Motion-led edits and visual effects.", colors: [[153, 167, 135], [202, 209, 187]] },
  { title: "Premiere Pro", mark: "Pr", level: "Proficient", description: "Reels, brand stories, and short films.", colors: [[170, 160, 142], [224, 215, 197]] },
  { title: "AI Video Creation", mark: "AI", level: "Familiar", description: "Higgsfield and HeyGen.", colors: [[152, 119, 97], [211, 183, 157]] },
];

function SkillCard({ skill, autoPlay }: { skill: (typeof skills)[number]; autoPlay: boolean }) {
  const cardRef = useRef<HTMLButtonElement>(null);
  const inView = useInView(cardRef, { amount: 0.55 });
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const [pinned, setPinned] = useState(false);
  const reducedMotion = useReducedMotion();
  const active = hovered || focused || pinned || (autoPlay && inView);

  return (
    <button
      type="button"
      ref={cardRef}
      className="toolkit-card"
      aria-label={`${skill.title}. ${skill.level}. ${skill.description} Toggle visual effect.`}
      aria-pressed={pinned}
      data-active={active}
      data-auto-play={autoPlay}
      onPointerEnter={(event) => { if (event.pointerType !== "touch") setHovered(true); }}
      onPointerLeave={() => setHovered(false)}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onClick={() => setPinned(!pinned)}
      onKeyDown={(event) => { if (event.key === "Escape") { setPinned(false); setHovered(false); setFocused(false); } }}
    >
      <AnimatePresence>
        {active && !reducedMotion && (
          <motion.div className="toolkit-effect" aria-hidden="true" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
            <Suspense fallback={<div className="toolkit-loading-dots" />}><CanvasRevealEffect animationSpeed={3} colors={skill.colors} dotSize={2} /></Suspense>
          </motion.div>
        )}
      </AnimatePresence>
      <span className="toolkit-content">
        <span className="toolkit-mark" aria-hidden="true">{skill.mark}</span>
        <span className="toolkit-title">{skill.title}</span>
        <span className="toolkit-level">{skill.level}</span>
        <span className="toolkit-description">{skill.description}</span>
      </span>
    </button>
  );
}

export default function CreativeToolkit() {
  const [autoPlay, setAutoPlay] = useState(false);
  useEffect(() => {
    const query = window.matchMedia("(hover: none), (pointer: coarse), (max-width: 760px)");
    const update = () => setAutoPlay(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  return (
    <section className="creative-toolkit" aria-labelledby="toolkit-heading">
      <div className="toolkit-heading"><h2 id="toolkit-heading">The tools behind the stories.</h2><p>{autoPlay ? "Motion comes into view as you scroll." : "Hover or tap to explore."}</p></div>
      <div className="toolkit-grid">
        {skills.map((skill) => <SkillCard key={skill.title} skill={skill} autoPlay={autoPlay} />)}
      </div>
    </section>
  );
}
