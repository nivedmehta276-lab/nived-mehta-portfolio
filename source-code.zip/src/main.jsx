import React, { Suspense, lazy } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/manrope/latin-400.css';
import '@fontsource/manrope/latin-500.css';
import '@fontsource/manrope/latin-600.css';
import '@fontsource/manrope/latin-700.css';
import '@fontsource/dm-sans/latin-400.css';
import '@fontsource/dm-sans/latin-500.css';
import '@fontsource/dm-sans/latin-600.css';
import PortfolioLoader from './components/PortfolioLoader';
import './index.css';

const App = lazy(() => import('./App'));

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Suspense fallback={<div className="initial-loader"><PortfolioLoader /></div>}><App /></Suspense>
  </React.StrictMode>
);
